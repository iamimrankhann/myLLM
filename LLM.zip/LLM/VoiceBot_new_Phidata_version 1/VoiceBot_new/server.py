import json,orjson
import sys

from modules import *
from Voicebot import *
from Agents import *
from extractor import Website_Scrapper
from assistant import *
app = FastAPI(max_request_size=1000*1024*1024)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"], )
# Custom classes
RAG = RAG()
VoiceBot = VoiceBot()
Advanced_RAG = Advanced_RAG()
# ASR model and LLM is needed to be declared only once. So it is declared globally
model = VoiceBot.asr_model()
# llm = GooglePalm(temperature=0)
llm =  GoogleGenerativeAI(model="gemini-pro",temperature=0.3, google_api_key="AIzaSyCmx2qVsVJ-rz8E4cRHaPo2NFbpEh79WJQ")

# Create a new client and connect to the server
# semantic_cache.clear()
# llmcache = SemanticCache(
#     name="llmcache",                     # underlying search index name
#     prefix="llmcache",                   # redis key prefix for hash entries
#     redis_url="redis://default:kEnoKLXt8vYYoZNWcZCMK1S7HcXriVTB@redis-15772.c274.us-east-1-3.ec2.cloud.redislabs.com:15772",  # redis connection url string
#     distance_threshold=0.1               # semantic cache distance threshold
# )
# set_llm_cache(semantic_cache)
# llm_cache = (RedisSemanticCache(redis_url="redis://default:kEnoKLXt8vYYoZNWcZCMK1S7HcXriVTB@redis-15772.c274.us-east-1-3.ec2.cloud.redislabs.com:15772", embedding=GooglePalmEmbeddings()))
# llm_cache.store()
# set_llm_cache(llm_cache)
# litellm.cache = Cache(
#     type="redis-semantic",
#     host=os.environ["REDIS_HOST"],
#     port=os.environ["15772"],
#     password=os.environ["REDIS_PASSWORD"],
#     similarity_threshold=0.8, # similarity threshold for cache hits, 0 == no similarity, 1 = exact matches, 0.5 == 50% similarity
#     redis_semantic_cache_embedding_model="text-embedding-ada-002", # this model is passed to litellm.embedding(), any litellm.embedding() model is supported here
# )
# llm = ChatGoogleGenerativeAI(model="gemini-pro",
#                  temperature=0.7, top_p=0.85)
# llm = genai.GenerativeModel('gemini-pro')
# llm = llm.start_chat(history=[])
# llm = ChatGoogleGenerativeAI(model="gemini-pro", google_api_key = "AIzaSyBcvQ_KcY2cr6-bBKEgdP6OE3j9t3RuBw4")
conv_memory = ConversationBufferMemory(memory_key="history", return_messages=True)
rag_memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
# The data has to be stored in the database only once. So it is declared globally
retriever = None
agent_executor = None
llm_os = None
#-----------------------------------------------------------------------------------------------------------------------
@app.post("/reset-variable/")
async def reset_variable():
    global retriever, agent_executor, llm_os
    global conv_memory, rag_memory
    conv_memory.clear()
    rag_memory.clear()
    retriever = None
    agent_executor = None
    llm_os=None
    print("INFO:    Variables reset successfully..........")
    return {"status": "Variable reset successfully"}

@app.post('/pdf/')
async def data_extraction(file: UploadFile = File(...)):
    start_time = time.time()
    global retriever, llm_os
    print("INFO:    PDF post request hit successfully")
    file_contents = await file.read()
    # Create a temporary file to write the contents
    with tempfile.NamedTemporaryFile(delete=False) as temp_file:
        temp_file.write(file_contents)
        temp_file.seek(0)
    doc = PyPDFLoader(temp_file.name).load_and_split()
    print("INFO:    PDF was loaded successfully!!!")
    retriever = RAG.pipeline(doc)
    print("INFO:    Retriever built successfully..........")
    print('\033[94m' + f'INFO:      Time taken for data extraction from PDF is {round(time.time() - start_time, 2)}s' + '\033[0m')
    if llm_os is None:
        print("INFO:    Creating LLM_OS !!!")
        llm_os = get_llm_os()
        # llm_os = get_llm_os(calculator=True, file_tools=True, shell_tools=True,ddg_search=True,python_assistant=True,investment_assistant=True, research_assistant=True,data_analyst=True)
    if retriever:
        print("INFO:    Adding Knowledge base to LLM_OS!!!!!!!-----------------------------")
        print("---------------------",type(retriever),"------")
        llm_os.knowledge_base = LangChainKnowledgeBase(retriever=retriever)
        # print("size--------", sys.getsizeof(llm_os), sys.getsizeof(retriever))
        # return orjson.dumps(retriever)
#-----------------------------------------------------------------------------------------------------------------------

@app.post('/website/')
async def data_extraction(link: str):
    start_time = time.time()
    print("INFO:   website post request hit successfully ")
    print("INFO:   Website is", link)
    global retriever, llm_os
    # doc = Website_Scrapper().data_extraction(link)
    loader = WebBaseLoader(link)
    docs = loader.load_and_split()
    print("INFO : Size of scrapped text : ", len(docs))
    # print("Scrapped text : ", docs)
    print("INFO: Website data is extracted successfully!")
    # doc = [Document(page_content=docs[0], metadata={"source": "local"})]
    print("INFO : Size of document : ", len(docs))

    retriever = RAG.pipeline(docs)
    print('\033[94m' + f'INFO:      Time taken for data extraction from website is {round(time.time() - start_time, 2)}s' + '\033[0m')
    # if llm_os is None:
    print("INFO:    Creating LLM_OS !!!")
    if llm_os is None:
        print("INFO:    Creating LLM_OS !!!")
        llm_os = get_llm_os()
        # llm_os = get_llm_os(calculator=True, file_tools=True, shell_tools=True,ddg_search=True,python_assistant=True,investment_assistant=True, research_assistant=True,data_analyst=True)
    if retriever:
        print("INFO:    Adding Knowledge base to LLM_OS!!!!!!!-----------------------------")
        print("---------------------",type(retriever),"------")
        llm_os.knowledge_base = LangChainKnowledgeBase(retriever=retriever)
    # llm_os = get_llm_os(calculator=True, file_tools=True, shell_tools=True,python_assistant=True)
    # if retriever:
    #     print("INFO:    Adding Knowledge base to LLM_OS!!!!!!!-----------------------------")
    #     print("---------------------",type(retriever),"------")
    #     llm_os.knowledge_base = LangChainKnowledgeBase(retriever=retriever)
#-----------------------------------------------------------------------------------------------------------------------

@app.post('/transcriber/')
async def voice_process(file:UploadFile = File(...)):
    start_time = time.time()
    print('INFO:   Post request recieved!!!')
    print(f"INFO:   {type(file.file)}")
    """ The uploaded file is received as tempfile.SpooledTemporaryFile
    so it needs to be converted to WAV or MP3"""
    received_file = "Received_audio.wav"
    audio = AudioSegment.from_file(file.file, format="wav")
    audio.export(received_file, format="wav")
    print(f"INFO:   Conversion completed. File saved as {received_file} and type {received_file.split('.')[1]}")
    #------------------------------------------------------------------------
    transcribed_text, language = VoiceBot.speech_to_text(model,received_file)
    print('\033[94m' + f'INFO:      Time taken for transcribing is {round(time.time() - start_time, 2)}s' + '\033[0m')
    print(transcribed_text, language)
    return transcribed_text, language

#-----------------------------------------------------------------------------------------------------------------------

@app.post('/llm/')
async def llm_process(query: str, session_id:str):
    start_time = time.time()
    print("INFO:    LLM post request hit successfully!!!!!!")
    print("session id in server module is : -------- ", session_id)
    global retriever
    global agent_executor, llm_os
#--------------------------------- phidata assistant start--------------------------------------

    if llm_os is None:
        return "Please provide A PDF or Website first !!!!"
    with st.chat_message("assistant"):
        answer = ""
        for delta in llm_os.run(query):
            answer+=delta
        print((answer))
        return answer
    # phidata assistant end

# -----------------------------------Agentic Workflow-----------------------------------------------
    # if agent_executor is None:
    #     rag_agent = RAG_AGENT(llm=llm, retriever=retriever)
    #     rag_tool = rag_agent.rag_tool()
    #     duck_tool = rag_agent.duckduckgo()
    #     tools = [rag_tool, duck_tool]
    #     # csv_tool = rag_agent.csv_tool("customers.csv")
    #     # tools.append(csv_tool)
    #
    #     prompt = hub.pull("hwchase17/structured-chat-agent")
    #     agent = create_structured_chat_agent(llm, tools, prompt)
    #     # Create an agent executor by passing in the agent and tools
    #     agent_executor = AgentExecutor(agent=agent, tools=tools, handle_parsing_errors=True)
    # # print(agent_executor)
    # result = agent_executor.invoke({"input": query})
    # print(result)
    # return result['output']

#--------------------------------- Agentic workflow end------------------------------------------
    if retriever:
        print("INFO:    Inside Retriever part of LLM....")
        try:
            answer = conv_llm_rag(query= query, retriever= retriever, llm= llm, memory= rag_memory, session_id= session_id)
        except Exception as error_message:
            print(f"INFO:    error is {error_message}")
            error_message = str(error_message)
            object_start_index = error_message.find("{")
            object_end_index = error_message.rfind("}") + 1
            object_string = error_message[object_start_index:object_end_index]
            # Convert the object string to a dictionary
            object_dict = ast.literal_eval(object_string)
            # Extract the 'text' field from the 'repr' value
            repr_string = object_dict.get('repr', '')
            text_start_index = repr_string.find("text='") + len("text='")
            text_end_index = repr_string.find("'", text_start_index)
            text = repr_string[text_start_index:text_end_index]

            print(text)
            answer = text
    else:
        print("INFO:    Retriever not found, so predicting from LLM....")
        # answer = conv_llm(query, llm, conv_memory)
        try:
            answer = conv_llm(query, llm, conv_memory)
        except Exception as error_message:
            print(f"INFO:    error is {error_message}")
            error_message = str(error_message)
            object_start_index = error_message.find("{")
            object_end_index = error_message.rfind("}") + 1
            object_string = error_message[object_start_index:object_end_index]

            # Convert the object string to a dictionary
            object_dict = ast.literal_eval(object_string)

            # Extract the 'text' field from the 'repr' value
            repr_string = object_dict.get('repr', '')
            text_start_index = repr_string.find("text='") + len("text='")
            text_end_index = repr_string.find("'", text_start_index)
            text = repr_string[text_start_index:text_end_index]

            print(text)
            answer = text

    print('\033[94m' + f'INFO:      Time taken for LLM is {round(time.time() - start_time, 2)}s' + '\033[0m')
    return answer
#-----------------------------------------------------------------------------------------------------------------------

@app.post('/voice_response/')
async def voice_response(transcribed_text: str, language:str):
    start_time = time.time()
    print("INFO:    Voice_response post request hit successfully!!!")
    audio_output = VoiceBot.text_to_speech(transcribed_text, language=language)
    # audio_output = VoiceBot.text_to_speech_11l(transcribed_text)
    print("INFO:    Voice response generated successfully.....")
    print((audio_output))
    print('\033[94m' + f'INFO:      Time taken for voice response= is {round(time.time() - start_time, 2)}s' + '\033[0m')
    return StreamingResponse(open(audio_output,"rb"),media_type='audio/mp3',headers={"Content-Disposition": "attachment; filename=output.mp3"})

#-----------------------------------------------------------------------------------------------------------------------

@app.post('/teams_trial')
async def trial(request:Request):
    # print("-----", request)
    request_body = await request.body()
    # req = {
    #     "headers": {
    #         "Authorization": "8aV0pnsrNiDfWN3KzdtrbJV7kys8o9Dg5DfxVqFansI="   # Replace with the provided HMAC value
    #     },
    #     "payload": "Hello, World!"
    # }
    # if verify_request(req, shared_secret):
    #     print("Request is authentic")
    # else:
    #     print("Request is not authentic")
    # Convert the request body from bytes to string
    request_body_str = request_body.decode('utf-8')
    # print("Request body string :", request_body_str)
    # Parse the request body as JSON
    request_data = json.loads(request_body_str)
    #For Extracting the trigger word to remove it from query string
    print("Request data :", request_data.get('attachments')[0].get('content'))
    html_string = request_data.get('attachments')[0].get('content')
    soup = BeautifulSoup(html_string, 'html.parser')
    trigger_word = soup.span.get_text()
    # print(trigger_word)



    activity_type = request_data.get('activity', {}).get('type')
    conversation_id = request_data.get('conversation', {}).get('id')
    from_user = request_data.get('from', {}).get('name')
    message_text = request_data.get('text')

    message_text = html.unescape(message_text)
    # Use a regular expression to extract only the text content
    message_text = re.sub(r'<[^>]+>', '', message_text)
    message_text = message_text[len(trigger_word)+1:]
    print("from user : ", from_user)
    print("type of message text :", type(message_text))
    print("message text : ", message_text)
    answer = conv_llm_rag(llm=llm, query=message_text, memory=rag_memory, retriever=retriever)
    payload = {
        "type": "message",
        "text": answer
    }
    return payload
#-----------------------------------------------------------------------------------------------------------------------

@app.post('/slack_trial')
async def trial(request:Request):
    print("-----", request)
    global retriever
    request_body = await request.body()

    request_body_str = request_body.decode("utf-8")
    print(request_body_str)
    parsed_data = parse_qs(request_body_str)
    data = {k: unquote(v[0]) for k, v in parsed_data.items()}
    # Convert the dictionary to a JSON string
    json_string = json.dumps(data)
    # Convert the JSON string back to a Python dictionary
    request_data = json.loads(json_string)
    trigger_word = request_data.get("trigger_word")
    message_text = request_data.get("text")
    print("trigger word:",trigger_word, "end of it")
    # print("len of trigger word : ", len(trigger_word))
    # message_text = message_text[len(trigger_word)+1:]
    print("message text : ", message_text)
    print("len of message text : ", len(message_text))
    answer = conv_llm_rag(llm=llm, query=message_text, memory=rag_memory, retriever=retriever)
    # Perform your desired actions with the extracted data
    payload = {
        "type": "message",
        "text": answer
    }
    return payload
#-----------------------------------------------------------------------------------------------------------------------

@app.post('/weather')
async def weather(location:str):
    response = weather_agent(location)
    return [response[0], response[1]]

@app.post('/location')
async def location():
    response = location_agent()
    return response['address']

@app.post('/agent')
async def agent(query:str):
    response = basic_agent(query)
    return response

@app.post('/sql_agent')
async def agent(query:str):
    response = sql_agent(query)
    return response


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)