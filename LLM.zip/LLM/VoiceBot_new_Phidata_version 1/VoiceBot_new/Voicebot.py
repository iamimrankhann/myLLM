# import server
import os,sys

from langchain.chains.conversation.base import ConversationChain
from langchain.chains.conversational_retrieval.base import ConversationalRetrievalChain
from langchain.chains.retrieval import create_retrieval_chain
from langchain_community.tools import DuckDuckGoSearchRun
from langchain_core.tools import create_retriever_tool, StructuredTool
from langchain_experimental.agents import create_csv_agent
from langchain_experimental.utilities import PythonREPL
from langchain.agents.agent_types import AgentType

from modules import *
chat_history = []

conversation = None
# semantic_cache = MongoDBAtlasSemanticCache(
#     # embedding=GooglePalmEmbeddings(),
#     embedding=HuggingFaceEmbeddings(),
#     connection_string='mongodb+srv://Cluster74590:f19982000@cluster74590.iahd7nm.mongodb.net/?retryWrites=true&w=majority&appName=Cluster74590',
#     collection_name="voice",
#     database_name="mongo",
#     index_name="vector_index",
#     score_threshold=0.99,
#
# )
# semantic_cache.clear()

class VoiceBot():

    def __init__(self):
        # Initialize logger
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.DEBUG)
        # Create a file handler and set the formatter
        log_file_path = os.path.join(os.getcwd(), "voice_bot.log")
        file_handler = logging.FileHandler(log_file_path)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)

        # Add the file handler to the logger
        self.logger.addHandler(file_handler)
    #----------------------------------------------------------
    def record(self, name="input_recording.wav",path=os.getcwd()):
        try:
            recognizer = sr.Recognizer()
            print("listening")
            with sr.Microphone() as source:
                recognizer.adjust_for_ambient_noise(source)
                audio = recognizer.listen(source, timeout=3)

            # Save the audio to a temporary file
            audio_file_path = os.path.join(path, name)
            with open(audio_file_path, "wb") as f:
                f.write(audio.get_wav_data())
            return audio_file_path

        except Exception as e:
            self.logger.error(f"Error during recording: {str(e)}")
            return None
    # ----------------------------------------------------------

    def asr_model(self, model_size='base'):
        try:
            model = whisper.load_model(model_size)
            return model
        except Exception as e:
            self.logger.error(f"Error loading ASR model: {str(e)}")
            return None

    # ----------------------------------------------------------
    def speech_to_text(self, model, input_audio="input_recording.wav"):
        # Language detection

        audio = whisper.load_audio(input_audio)
        audio = whisper.pad_or_trim(audio)
        mel = whisper.log_mel_spectrogram(audio).to(model.device)
        _, probs = model.detect_language(mel)
        detected_language = max(probs, key=probs.get)
        # detected_language = 'en'
        start_time = time.time()
        text = model.transcribe(input_audio, fp16=False)
        print(text)
        print(
            '\033[94m' + f'INFO:      Time taken for transcribing is {round(time.time() - start_time, 2)}s' + '\033[0m')
        print(f"Detected Language: '{detected_language}' and Transcribed Text: '{text['text']}'")
        # if detected_language == 'en':
        return text['text'], detected_language
        # else:
        #     translator = Translator()
        #     translated_text = translator.translate(text['text'], dest='en').text
        #     return translated_text, detected_language
    # ----------------------------------------------------------
    def text_to_speech(self, text, path=os.getcwd(),name='output_speech.wav',language='en'):
        try:
            myobj = gTTS(text=text, lang=language, slow=False, tld="co.uk")
            audio_file_path = os.path.join(path, name)
            myobj.save(name)
            return name
        except Exception as e:
            self.logger.error(f"Error during text-to-speech conversion: {str(e)}")
            return None

    def text_to_speech_11l(self, text ,chunk_size = 1024,voice_id = "21m00Tcm4TlvDq8ikWAM", model_id = "eleven_multilingual_v2", path = os.getcwd(), name='xi_output_speech.mp3'):
        tts_url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}/stream"
        headers = {
            "Accept": "application/json",
            "xi-api-key": os.getenv("ELEVEN_API_KEY")
        }
        data = {
            "text": text,
            "model_id": model_id,
            "voice_settings": {
                "stability": 0.5,
                "similarity_boost": 0.8,
                "style": 0.0,
                "use_speaker_boost": True
            }
        }
        response = requests.post(tts_url, headers=headers, json=data, stream=True)
        if response.ok:
            OUTPUT_PATH = "eleven_labs_output.mp3"
            # Open the output file in write-binary mode
            with open(OUTPUT_PATH, "wb") as f:
                # Read the response in chunks and write to the file
                for chunk in response.iter_content(chunk_size=chunk_size):
                    f.write(chunk)
            # Inform the user of success
            print("Audio stream saved successfully.")
            return OUTPUT_PATH
        else:
            # Print the error message if the request was not successful
            print(response.text)
            return None


# -----------------------------------------------------------------------------------------------------------------------------------

class RAG():
    def __init__(self):
        # Configure logging
        logging.basicConfig(filename='rag_log.txt', level=logging.ERROR)

    # ----------------------------------------------------------
    def rag_splitter(self, doc, chunk_size=200, overlap=40):
        # doc should be in format of " Document(page_content='LayoutParser : A Uni\x0ced Toolkit for .....)
        # This doc is the output of loading a document using loaders from langchain and load_and_split()
        try:
            splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=overlap)
            chunks = splitter.split_documents(doc)
            return chunks
        except Exception as e:
            logging.error(f"Error in rag_splitter: {e}")
            return None

    # ----------------------------------------------------------
    def rag_embeddings(self, embedding_name='Huggingface'):
        try:
            if embedding_name == 'palm':
                embeddings = GooglePalmEmbeddings()
            else:
                embeddings_model_name = "sentence-transformers/all-MiniLM-L6-v2"
                embeddings = HuggingFaceEmbeddings(model_name=embeddings_model_name)
            return embeddings
        except Exception as e:
            logging.error(f"Error in rag_embeddings: {e}")
            return None

    # ----------------------------------------------------------
    def rag_vectorstore(self, chunks, rag_embeddings, vector_name='FAISS'):
        try:
            if vector_name == 'chroma':
                retriever = (Chroma.from_documents(chunks, rag_embeddings)).as_retriever()
            else:
                retriever = (FAISS.from_documents(chunks, rag_embeddings)).as_retriever()
            return retriever
        except Exception as e:
            logging.error(f"Error in rag_vectorstore: {e}")
            return None

    def pipeline(self, doc):
        chunks = self.rag_splitter(doc)
        embeddings = self.rag_embeddings()
        retriever = self.rag_vectorstore(chunks, embeddings)
        # print("Type of retriever in VoiceBot module----", type(retriever))
        return retriever
# --------------------------------------------------------------------------------------------------------------------------
class Advanced_RAG():
    def __init__(self):
        # Configure logging
        logging.basicConfig(filename='rag_log.txt', level=logging.ERROR)

    def rag_embedding(self, embedding_name='Huggingface'):
        try:
            if embedding_name == 'palm':
                embeddings = GooglePalmEmbeddings()
            else:
                embeddings_model_name = "sentence-transformers/all-MiniLM-L6-v2"
                embeddings = HuggingFaceEmbeddings(model_name=embeddings_model_name)
            return embeddings
        except Exception as e:
            logging.error(f"Error in rag_embeddings: {e}")
            return None

    def vectorstore(self, rag_embedding, name="FAISS"):
        if name=='chroma':
            vector= Chroma(embedding_function=rag_embedding)
        else:
            vector = FAISS(embedding_function=rag_embedding)

        return vector

    def rag_retriever(self, doc, vectorstore, parent_splitter_size = 2000 , child_splitter_size = 200, overlap = 20):
        try:
            parent_splitter = RecursiveCharacterTextSplitter(chunk_size=parent_splitter_size)
            child_splitter = RecursiveCharacterTextSplitter(chunk_size= child_splitter_size)
            store = InMemoryStore()
            retriever = ParentDocumentRetriever(
                vectorstore=vectorstore,
                docstore=store,
                child_splitter=child_splitter,
                parent_splitter=parent_splitter,
            )
            retriever.add_documents(doc)
            return retriever
        except Exception as e:
            print((f"INFO: Unable to build embeddings, error : {e}!"))
            logging.error(f"Error while building embeddings {e}")

    def pipeline(self, doc):
        rag_embedding = self.rag_embedding("Huggingface")
        vectorstore = self.vectorstore(rag_embedding)
        retriever =  self.rag_retriever(doc, vectorstore )
        return retriever

# Agentic RAG workflow -------------------------------------
class RAG_AGENT():

    def __init__(self, llm=ChatGoogleGenerativeAI(model= "gemini-pro"), retriever=None):
        self.llm = llm
        self.retriever = retriever

    def rag_tool(self):
        retriever_tool = create_retriever_tool(
            self.retriever,
            name="retriever",
            description = "Search and return information from the documents provided for retrival augmentation generation ",
        )
        return retriever_tool
    def python_tool(self):
        python_repl = PythonREPL()
        repl_tool = Tool(
            name="python_repl",
            description="A Python shell. Use this to execute python commands. Input should be a valid python command. If you want to see the output of a value, you should print it out with `print(...)`.",
            func=python_repl.run,
        )
        return repl_tool

    def csv_tool(self, csv_path, llm):
        csv_agent = create_csv_agent(
            llm=llm,
            path=csv_path,
            verbose=True,
            agent_type=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
            allow_dangerous_code=True,
        )

        def csv_agent_func(input: str) -> str:
            """Used for answering question related to CSV file"""
            return csv_agent.run(input)

        csv_tool = StructuredTool.from_function(func=csv_agent_func)
        return csv_tool

    def duckduckgo(self):
        def duck_search(input: str) -> str:
            """Used for answering question to recent event or from the internet"""
            duck = DuckDuckGoSearchRun()
            return duck.run(input)

        duck_search_tool = StructuredTool.from_function(duck_search)
        return duck_search_tool

    def agent_intialization(self):
        # rag_agent = RAG_AGENT(llm=llm, retriever=retriever)
        rag_tool = self.rag_tool()
        duck_tool = self.duckduckgo()
        tools = [rag_tool, duck_tool]
        # if(self.csv_path):
        #     csv_tool = self.csv_tool(self.csv_path, self.llm)
        #     tools.append(csv_tool)
        prompt = hub.pull("hwchase17/structured-chat-agent")
        agent = create_structured_chat_agent(self.llm, tools, prompt)
        # Create an agent executor by passing in the agent and tools
        agent_executor = AgentExecutor(agent=agent, tools=tools, handle_parsing_errors=True)
        return agent_executor


def get_session_history(session_id):
    print("session id is : -------- ",session_id)
    return SQLChatMessageHistory(session_id, "sqlite:///memory.db")

# ----------------------------------------------------------




# ----------------------------------------------------------

def conv_llm_rag(query, retriever, llm, memory,session_id):
    # cached_entry = semantic_cache.similarity_search_with_relevance_scores(query, 5)
    # print(cached_entry)
    # if (cached_entry and cached_entry[0][1] <= 0.03):
    #     answer = cached_entry[0][0].to_json()['kwargs']['metadata']['response']
    #     return answer
    global conversation
    # llm_prompt_template = """You are an assistant for question-answering tasks.
    # Use the following context to answer the question.
    # If you don't know the answer, just say that you don't know.
    # Use five sentences maximum and keep the answer concise.\n
    # Question: {question} \nContext: {context} \nAnswer:"""
    #
    # llm_prompt = PromptTemplate.from_template(llm_prompt_template)
    # print(llm_prompt)
    # rag_chain = (
    #         {"context": retriever, "question": RunnablePassthrough()}
    #         | llm_prompt
    #         | llm
    #         | StrOutputParser()
    # )
    # ans = rag_chain.invoke(query)
    # print(ans)
    # return ans
    # question_generator_chain = LLMChain(llm=llm, prompt=prompt)

        # print(answer)
    # ConversationalRetrievalQA should be declared only once, not everytime LLM fastapi endpoint is called, So it is declared globally and only once
    print("convo chain---")
    # template = """You are chatbot.YOU PROVIDE INFORMATION FROM DOCUMENT PROVIDED ONLY.\n
    # You also have chat history.Gather informations from the provided DOCUMENT and provide the answer to the points only.\n
    #             If you are asked to answer in brief or detail, then try to answer in brief and detail respectively.\n
    #              Never makeup answer on your own. IF QUESTION IS NOT ASKED FROM THE PROVIDED DOCUMENT, SAY "Sorry, I dont know the answer". DO NOT MAKE ANSWER ON YOUR OWN.
    #              I REPEAT IF QUESTION IS NOT FROM PROVIDED DOCUMENT, DO NOT ANSWER THAT QUESTION. JUST SAY "SORRY" EVEN IF ANSWER IS QUIET KNOWN.
    #         ----
    #         {context}
    #         ----
    #         """
    #
    #
    # general_user_template = "Question:```{question}```"
    # messages = [
    #     SystemMessagePromptTemplate.from_template(template),
    #     HumanMessagePromptTemplate.from_template(general_user_template)
    # ]
    # qa_prompt = ChatPromptTemplate.from_messages(messages)
    # checking if conversation is defined already. It will be defined only once
    if len(memory.load_memory_variables({})['chat_history']) <= 1:
        contextualize_q_system_prompt = (
            "Given a chat history and the latest user question "
            "which might reference context in the chat history, "
            "formulate a standalone question which can be understood "
            "without the chat history. Do NOT answer the question, "
            "just reformulate it if needed and otherwise return it as is."
        )

        contextualize_q_prompt = ChatPromptTemplate.from_messages([
            ("system", contextualize_q_system_prompt),
            MessagesPlaceholder("chat_history"),
            ("human", "{input}"), ])

        history_aware_retriever = create_history_aware_retriever(llm, retriever, contextualize_q_prompt)
        # ---------------------------------------------------------------------------------------------------------------------------
        system_prompt = (
            "You are an assistant for question-answering tasks. "
            "Do not answer from your own knowledge source, general knowledge that you are trained upon."
            "Do not answer if the information is not from the retrieved context."
            "Use the following pieces of retrieved context to answer "
            "the question. If you don't know the answer, say that you "
            "don't know."
            " Use three sentences maximum and keep the "
            "answer concise."
            "\n\n"
            "{context}"
        )

        qa_prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt),
            MessagesPlaceholder("chat_history"),
            ("human", "{input}")])
        # ---------------------------------------------------------------------------------------------------------------------------
        now = time.time()
        question_answer_chain = create_stuff_documents_chain(llm, qa_prompt)
        rag_chain = create_retrieval_chain(history_aware_retriever, question_answer_chain)

        conversation = RunnableWithMessageHistory(
            rag_chain,
            get_session_history,
            input_messages_key="input",
            history_messages_key="chat_history",
            output_messages_key="answer",

        )
    # rag_logger.info(f"Time Taken for creating chains : {round(time.time() - now, 2)}s")
    # return conversational_rag_chain
    # if len(memory.load_memory_variables({})['chat_history']) <= 1:
    #     conversation = ConversationalRetrievalChain.from_llm(combine_docs_chain_kwargs={"prompt": qa_prompt},
    #                                                          llm=llm,
    #                                                          retriever=retriever, memory=memory, verbose=True)

    answer = conversation.invoke({"input": query}, config={"configurable": {"session_id": session_id}},
                              # constructs a key "abc123" in `store`.
                              )
    chat_history.extend(["User : " + query, "ChatBot : " + answer["answer"]])
    # answer = conversation({"question": query})
    # cached_res = semantic_cache._insert_texts(
    #     [query],
    #     [{"response": answer['answer']}],
    #     # This ensures that if the query doesn't exist, it will be inserted
    # )
    # print("answer : ", answer)
    return answer['answer']


# ----------------------------------------------------------

def conv_llm(query, llm, memory):

    global conversation
    # ans = llm.generate_content(query).text
    # return llm.send_message(query).text

    cached_entry = semantic_cache.similarity_search_with_relevance_scores(query,5)
    # if cached_entry:
    #     print("----------------", cached_entry[0][1])
    if(cached_entry and cached_entry[0][1]<=0.03):
        print("----------------", cached_entry[0][1])
        answer = (cached_entry[0][0].to_json()['kwargs']['metadata']['response'])
        return answer

    # checking if conversation is defined already. It will be defined only once
    if len(memory.load_memory_variables({})['history']) <=1 :
        conversation = ConversationChain(llm=llm, memory=memory, verbose=True)
    answer =conversation.predict(input = query)
    # print(type(answer))
    # llm = ChatGoogleGenerativeAI(model="gemini-pro", google_api_key = "AIzaSyBcvQ_KcY2cr6-bBKEgdP6OE3j9t3RuBw4")
    # tweet_prompt = PromptTemplate.from_template("You are a content creator. Write me a tweet about {topic}.")
    # tweet_chain = LLMChain(llm=llm, prompt=tweet_prompt, verbose=True)
    # answer = tweet_chain.predict(input = query)
    cached_res = semantic_cache._insert_texts(
        [query],
        [{"response": answer}],
        # This ensures that if the query doesn't exist, it will be inserted
    )
    print("answer : ", answer)
    return answer
