import base64
import wave
import requests
import json
import io
import ast
from io import BytesIO
import tempfile
import os
import time
import html
import re
import logging
import PyPDF2
from urllib.parse import quote_plus
import google
from bs4 import BeautifulSoup
import numpy as np
import shutil
from PyPDF2 import PdfReader
from urllib.parse import parse_qs, unquote
import warnings
warnings.filterwarnings("ignore")
#----------------------------------------------------ASR & TTS----------------------------------------------------------


import streamlit as st
import whisper
from gtts import gTTS
import speech_recognition as sr
from pydub import AudioSegment
import streamlit.components.v1 as components
# from streamlit_modal import Modal

#---------------------------------------------FastAPI-------------------------------------------------------------------

import uvicorn
from fastapi import FastAPI, UploadFile, HTTPException, File, Form, Request,Depends
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from urllib.parse import urljoin

#----------------------------------------------Langchain----------------------------------------------------------------

from sentence_transformers import SentenceTransformer
from langchain.docstore.document import Document
from langchain.retrievers import ParentDocumentRetriever
from langchain.storage import InMemoryStore
from langchain_community.cache import SQLiteCache, InMemoryCache, RedisSemanticCache
from langchain.globals import set_llm_cache
from langchain_community.document_loaders import WebBaseLoader, PyPDFLoader
from langchain_community.vectorstores import FAISS, Chroma, Redis, Milvus, Annoy
from langchain_community.vectorstores.utils import DistanceStrategy
from langchain_community.llms import GooglePalm, Cohere, OpenAI
from langchain_community.embeddings import GooglePalmEmbeddings, CohereEmbeddings, HuggingFaceEmbeddings, GPT4AllEmbeddings, TensorflowHubEmbeddings, OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains import ConversationalRetrievalChain, LLMChain, RetrievalQA, ConversationChain
from langchain.prompts import PromptTemplate, SystemMessagePromptTemplate, HumanMessagePromptTemplate, ChatPromptTemplate
from langchain.memory import ConversationSummaryMemory, ConversationBufferMemory
from langchain_google_genai.chat_models import ChatGoogleGenerativeAI  # update
from langchain.chains.question_answering import load_qa_chain
from langchain.schema.runnable import RunnablePassthrough
from langchain.schema import StrOutputParser
from langchain.schema.language_model import BaseLanguageModel
from langchain.agents import AgentExecutor, create_react_agent
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain.agents import Tool, load_tools, initialize_agent
from tavily import TavilyClient
from langchain.chains import LLMMathChain
from langchain_community.tools.yahoo_finance_news import YahooFinanceNewsTool
from langchain_community.tools import YahooFinanceNewsTool
from langchain_community.agent_toolkits.jira.toolkit import JiraToolkit
from langchain_community.utilities.jira import JiraAPIWrapper
from langchain.chains.llm_math.base import LLMMathChain
from langchain_community.utilities import SQLDatabase
from langchain_experimental. sql import SQLDatabaseChain

import getpass, os, pymongo, pprint
# from redisvl.extensions.llmcache import SemanticCache

from langchain.agents import create_react_agent, create_structured_chat_agent
from langchain import hub


from langchain_community.document_loaders import PyPDFLoader
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_mongodb import MongoDBAtlasVectorSearch, MongoDBAtlasSemanticCache
from langchain.prompts import PromptTemplate
from langchain import hub
from langchain.text_splitter import RecursiveCharacterTextSplitter
from pymongo import MongoClient
from langsmith import traceable
import geocoder

import google.generativeai as genai

# os.environ["LANGCHAIN_TRACING_V2"] = "True"
# os.environ["LANGCHAIN_API_KEY"] = "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"
# os.environ["LANGCHAIN_PROJECT"] = "default"
os.environ['COHERE_API_KEY'] = "NgG7KnIRqcGXhHA5G3p9n9bF62imcga3tCDDHWpD"
# os.environ["OPENAI_API_KEY"] = "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"
os.environ["GOOGLE_API_KEY"] = "AIzaSyCmx2qVsVJ-rz8E4cRHaPo2NFbpEh79WJQ"
# os.environ["ANTHROPIC_API_KEY"] = "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"
# os.environ['WEATHER_API_KEY'] = "e74c184c865b47faab2120814241804"
os.environ["TAVILY_API_KEY"] = "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"
os.environ["ELEVEN_API_KEY"] = "08a57ce991d1407f522f250212287f44"
os.environ["EXA_API_KEY"] = "988d4c9c-a54a-4431-b70b-898cf8430a98"
os.environ["XI_API_KEY"] = "08a57ce991d1407f522f250212287f44"
# LOCATION_API_KEY = os.getenv("pk.8241dc1d5f07de7c85497576a2415723")
# GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
# genai.configure(api_key=GOOGLE_API_KEY)






from langchain_google_genai import GoogleGenerativeAI,ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain_core.messages import AIMessage, HumanMessage
from langchain.chains import create_history_aware_retriever, create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.tools.tavily_search import TavilySearchResults
from langgraph.prebuilt import create_react_agent
# from langchain_cohere import ChatCohere
from langchain.agents import Tool, initialize_agent
from langchain_community.agent_toolkits.load_tools import load_tools

from tavily import TavilyClient
# from langchain_anthropic import ChatAnthropic
# from langchain_groq import ChatGroq
from langchain_community.document_loaders import PyPDFLoader,WebBaseLoader
import warnings
from langchain.chains.history_aware_retriever import create_history_aware_retriever
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_community.chat_message_histories import SQLChatMessageHistory
warnings.simplefilter('ignore', category=Warning)