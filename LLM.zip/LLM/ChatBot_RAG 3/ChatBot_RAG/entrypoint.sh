#!/bin/bash

cd /app/
#python3 server.py > /dev/null &
streamlit run frontend.py
