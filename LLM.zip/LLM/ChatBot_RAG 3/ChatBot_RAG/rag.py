import time
import logging
import tempfile
import streamlit as st
from langchain_google_genai import GoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain_core.messages import AIMessage, HumanMessage
from langchain.chains import create_history_aware_retriever, create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader,WebBaseLoader
import warnings
warnings.simplefilter('ignore', category=Warning)
############################################################################################################################################
logging.basicConfig(filename='rag.log', level=logging.INFO,format='%(asctime)s - %(levelname)s - %(message)s')
global rag_logger
rag_logger = logging.getLogger(__name__)
now = time.time()
llm =  GoogleGenerativeAI(model="gemini-pro", google_api_key="AIzaSyCm8QJvKrHgn52YWcjC4kHLQkoWNtiPP-U")
embedding=HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
rag_logger.info(f"Time Taken for loading embedding model and llm : {round(time.time() - now,2)}s")
# embedding=GoogleGenerativeAIEmbeddings(model="models/embedding-001", google_api_key="AIzaSyBcvQ_KcY2cr6-bBKEgdP6OE3j9t3RuBw4")
############################################################################################################################################
def rag_pipeline(docs,llm,embedding):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    splits = text_splitter.split_documents(docs)
    now = time.time()
    vectorstore = FAISS.from_documents(documents=splits,embedding=embedding)
    rag_logger.info(f"Time Taken for embedding and vector storing : {round(time.time()-now,2)}s")
    retriever = vectorstore.as_retriever()
    # ---------------------------------------------------------------------------------------------------------------------------
    contextualize_q_system_prompt = (
        "Given a chat history and the latest user question "
        "which might reference context in the chat history, "
        "formulate a standalone question which can be understood "
        "without the chat history. Do NOT answer the question,if is not from the context ")

    contextualize_q_prompt = ChatPromptTemplate.from_messages([
            ("system", contextualize_q_system_prompt),
            MessagesPlaceholder("chat_history"),
            ("human", "{input}"),])

    history_aware_retriever = create_history_aware_retriever(llm, retriever, contextualize_q_prompt)
    #---------------------------------------------------------------------------------------------------------------------------
    system_prompt = ("You are an assistant for question-answering tasks. Use the following pieces of retrieved context to answer "
        "the question. If you don't know the answer, say that you don't know. Use three sentences maximum and"
        " keep the answer concise.\n\n"
        "{context}" )

    qa_prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt),
            MessagesPlaceholder("chat_history"),
            ("human", "{input}")])
    # ---------------------------------------------------------------------------------------------------------------------------
    now = time.time()
    question_answer_chain = create_stuff_documents_chain(llm, qa_prompt)
    rag_chain = create_retrieval_chain(history_aware_retriever, question_answer_chain)
    rag_logger.info(f"Time Taken for creating chains : {round(time.time() - now,2)}s")
    return rag_chain
############################################################################################################################################
def rag_conv(rag_chain,question,chat_history):
    now = time.time()
    ai_msg = rag_chain.invoke({"input": question, "chat_history": chat_history})
    chat_history.extend([HumanMessage(content=question),AIMessage(content=ai_msg["answer"])])
    rag_logger.info(f"Time Taken for answering : {round(time.time()-now,2)}s")
    return ai_msg["answer"]
############################################################################################################################################