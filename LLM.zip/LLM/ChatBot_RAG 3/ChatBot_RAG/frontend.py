from rag import *

############################################################################################################################################
# Custom CSS for styling
custom_css = """
<style>
.conversation {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    margin: 10px;
}

.user-message {
    align-self: flex-end;
    padding: 10px;
    border-radius: 10px;
    margin-bottom: 5px;
    max-width: 70%;
    text-align: left;
    color: #ff7d00;
}

.bot-message {
    align-self: flex-start;
    padding: 10px;
    border-radius: 10px;
    margin-bottom: 5px;
    max-width: 70%;
    text-align: left;
    color: #48cae4;
}
</style>
"""
st.markdown(custom_css, unsafe_allow_html=True)



# Initialize session state variables
if 'initialized' not in st.session_state:
    st.session_state.initialized = True
    st.session_state.rag_chain = None
    st.session_state.chat_history = []
    st.session_state.previous_search_option = None
    st.session_state.previous_url = None
    st.session_state.previous_pdf_name = None

# Function to reset rag_chain, chat_history, and clear cache
def reset_rag_chain():
    st.session_state.rag_chain = None
    st.session_state.chat_history = []
    st.cache_data.clear()
############################################################################################################################################
# Side Panel
with st.sidebar:
    st.markdown("<h1 style='text-align: center;'>Please give your inputs here: \U0001F447</h1>", unsafe_allow_html=True)
    st.write("")
    st.markdown("<h3>Please enter the type of input</h3>", unsafe_allow_html=True)
    search_option = st.radio("Enter the search option", ['Pdf', 'Website'])

    # Reset rag_chain if search_option changes
    if st.session_state.previous_search_option != search_option:
        reset_rag_chain()
    st.session_state.previous_search_option = search_option

    if search_option == "Website":
        url_input = st.text_input("Enter the URL")
        if st.button("Submit") and url_input:
            if st.session_state.previous_url != url_input:
                reset_rag_chain()
                st.session_state.previous_url = url_input
            now= time.time()
            docs = WebBaseLoader(url_input).load_and_split()
            rag_logger.info(f"Time taken for webscrapping : {round(time.time()-now,2)}s")
            st.session_state.rag_chain = rag_pipeline(docs,llm,embedding)

            st.session_state.chat_history = []
            st.markdown("Website scraped successfully!!!")
    elif search_option == "Pdf":
        st.markdown("<h3>Please upload a file which can be pdf or zip</h3>", unsafe_allow_html=True)
        file = st.file_uploader("Please upload a file which can be pdf or zip", label_visibility="collapsed", type=["pdf"])
        if st.button("Submit") and file:
            if st.session_state.previous_pdf_name != file.name:
                reset_rag_chain()
                st.session_state.previous_pdf_name = file.name
            now = time.time()
            file_contents = file.read()
            with tempfile.NamedTemporaryFile(delete=False) as temp_file:
                temp_file.write(file_contents)
                temp_file.seek(0)

            docs = PyPDFLoader(temp_file.name).load_and_split()
            rag_logger.info(f"Time taken for PDF Loading : {round(time.time() - now, 2)}s")
            st.session_state.rag_chain = rag_pipeline(docs, llm,embedding)
            st.session_state.chat_history = []
            st.markdown("PDF scraped successfully!!!")
############################################################################################################################################
# Main Page
st.markdown("# TE PROMPT")
st.markdown("## Voice Assistant")
st.write("")

if st.session_state.rag_chain:
    st.markdown("<h6>Type your query.</h6>", unsafe_allow_html=True)
    user_input = st.text_input("Type the query", label_visibility="collapsed", key="user_input")
    if st.button("Send"):
        result = rag_conv(st.session_state.rag_chain, user_input, st.session_state.chat_history)
        # Display conversation
    t = 0
    for idx in st.session_state.chat_history:
        if t % 2 == 0:
            st.markdown(f'<div class="user-message">User : {idx.to_json()["kwargs"]["content"]}</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="bot-message">Bot : {idx.to_json()["kwargs"]["content"]}</div>', unsafe_allow_html=True)
        t += 1
else:
    st.markdown('Please enter Website or Upload a pdf')
############################################################################################################################################