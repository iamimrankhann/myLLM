import base64
import wave
import requests
import json
import io
import ast
from io import BytesIO
import tempfile
import os
import time
import html
import re
import logging
import PyPDF2
from urllib.parse import quote_plus
import google
from bs4 import BeautifulSoup
import numpy as np
import shutil
from PyPDF2 import PdfReader
from googletrans import Translator
from urllib.parse import parse_qs, unquote
import warnings
warnings.filterwarnings("ignore")
#----------------------------------------------------ASR & TTS----------------------------------------------------------

from langchain import hub
import streamlit as st
import whisper
from gtts import gTTS
import speech_recognition as sr
from pydub import AudioSegment
import streamlit.components.v1 as components
from streamlit_modal import Modal

#---------------------------------------------FastAPI-------------------------------------------------------------------

import uvicorn
from fastapi import FastAPI, UploadFile, HTTPException, File, Form, Request,Depends
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from urllib.parse import urljoin

#----------------------------------------------Langchain----------------------------------------------------------------
from sentence_transformers import SentenceTransformer
from langchain.docstore.document import Document
from langchain.retrievers import ParentDocumentRetriever
from langchain.storage import InMemoryStore
from langchain.cache import SQLiteCache, InMemoryCache, RedisSemanticCache
from langchain.globals import set_llm_cache
from langchain.document_loaders import WebBaseLoader, PyPDFLoader
from langchain.vectorstores import FAISS, Chroma, Redis, Milvus, Annoy
from langchain.vectorstores.utils import DistanceStrategy
from langchain.llms import GooglePalm, Cohere, OpenAI
from langchain.embeddings import GooglePalmEmbeddings, CohereEmbeddings, HuggingFaceEmbeddings, GPT4AllEmbeddings, TensorflowHubEmbeddings, OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains import ConversationalRetrievalChain, LLMChain, RetrievalQA, ConversationChain
from langchain.prompts import PromptTemplate, SystemMessagePromptTemplate, HumanMessagePromptTemplate, ChatPromptTemplate
from langchain.memory import ConversationSummaryMemory, ConversationBufferMemory
from langchain_google_genai.chat_models import ChatGoogleGenerativeAI  # update
from langchain.chains.question_answering import load_qa_chain
from langchain.schema.runnable import RunnablePassthrough
from langchain.schema import StrOutputParser
from langchain.schema.language_model import BaseLanguageModel
from langchain.agents import AgentExecutor
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain.agents import Tool, load_tools, initialize_agent
from tavily import TavilyClient
from langchain.chains import LLMMathChain
from langchain_community.tools.yahoo_finance_news import YahooFinanceNewsTool
from langchain.tools import YahooFinanceNewsTool

import getpass, os, pymongo, pprint
# from redisvl.extensions.llmcache import SemanticCache

from langchain_community.document_loaders import PyPDFLoader, WebBaseLoader
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_mongodb import MongoDBAtlasVectorSearch, MongoDBAtlasSemanticCache
from langchain.prompts import PromptTemplate
from langchain.text_splitter import RecursiveCharacterTextSplitter
from pymongo import MongoClient

import geocoder

import google.generativeai as genai
os.environ['COHERE_API_KEY'] = "NgG7KnIRqcGXhHA5G3p9n9bF62imcga3tCDDHWpD"
os.environ["OPENAI_API_KEY"] = "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"
os.environ["GOOGLE_API_KEY"] = "AIzaSyC3BBLZ2s5FKpHjgDrDpvRPmDHuSQL7KwA"
os.environ['WEATHER_API_KEY'] = "e74c184c865b47faab2120814241804"
# os.environ["TAVILY_API_KEY"] = "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"


LOCATION_API_KEY = os.getenv("pk.8241dc1d5f07de7c85497576a2415723")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
genai.configure(api_key=GOOGLE_API_KEY)
