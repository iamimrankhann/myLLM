import os

import requests
from modules import *

llm = GooglePalm()

def weather_agent(location):
    api_key = os.getenv("WEATHER_API_KEY")
    url = f"http://api.weatherapi.com/v1/current.json?key={api_key}&q={location}"
    response = requests.get(url)
    response = response.json()
    print(response)
    return [ response['current']['condition'] ,response['current']['temp_c'] ]

def location_agent():
    api_key = LOCATION_API_KEY
    location = geocoder.ip('me')
    lat = location.latlng[0]
    lng = location.latlng[1]
    print(lat ,lng)
    url = f"https://nominatim.openstreetmap.org/reverse?format=json&lat={lat}&lon={lng}"

    # url = f"https://us1.locationiq.com/v1/reverse?key={api_key}&lat={lat}&lon={lng}"
    response = requests.get(url).json()
    print(response)
    # response = response.json()

    return response

def basic_agent(query):
    tavily = TavilyClient(api_key="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")
    search_tool = Tool(
        name = "search",
        func = tavily.search,
        description = "Useful for answering about recent events or news"
    )
    llm_math = LLMMathChain(llm=llm)

    # initialize the math tool
    math_tool = Tool(
        name='Calculator',
        func=llm_math.run,
        description='Useful for when you need to answer questions about math.'
    )
    finance = Tool(
        name = "Finance",
        func = YahooFinanceNewsTool().run,
        description="Useful for when you need to find financial news about a public company. Input should be a company ticker. For example, AAPL for Apple, MSFT for Microsoft.'"
    )
    # finance = load_tools(["YahooFinanceNewsTool"])
    tools = [search_tool, math_tool]
    zero_agent = initialize_agent(
        agent= "zero-shot-react-description",
        tools = tools,
        llm=GooglePalm(),
        verbose = True,
        handle_parsing_errors=True,
        max_iterations = 6
    )

    answer = zero_agent(query)
    return answer