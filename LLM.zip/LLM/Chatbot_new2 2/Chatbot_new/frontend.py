
from Voicebot import VoiceBot
from modules import *
import server
custom_css = """
<style>
.conversation {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    margin: 10px;
}

.user-message {
    align-self: flex-end;
    padding: 10px;
    border-radius: 10px;
    margin-bottom: 5px;
    max-width: 70%;
    text-align: left;
    color: #00008B; /* Set font color to match the background color */
}

.bot-message {
    align-self: flex-start;
    padding: 10px;
    border-radius: 10px;
    margin-bottom: 5px;
    max-width: 70%;
    text-align: left;
    color: #007F00; /* Set font color to match the background color */
}
</style>
"""

# server.retriever = None
# server.retriever = None
server.rag_memory.clear()
st.markdown(custom_css, unsafe_allow_html=True)
voicebot = VoiceBot()
string =", ,         Do you have any other question      "
# if st.button("Click to open pop-up"):
#         # Pop-up modal content
#         Modal(
#             "Demo Modal",
#             key="demo-modal",
#
#             # Optional
#             padding=20,  # default value
#             max_width=744  # default value
#         )

# modal = Modal(
#     "Agents",
#     key="demo-modal",
#
#     # Optional
#     padding=20,  # default value
#     max_width=744  # default value
# )
# open_modal = st.button("Open")
# if open_modal:
#     modal.open()
#
# if modal.is_open():
#     with modal.container():
#         st.write("Text goes here")
#
#         html_string = '''
#         <h1>HTML string in RED</h1>
#
#         <script language="javascript">
#           document.querySelector("h1").style.color = "red";
#         </script>
#         '''
#         components.html(html_string)
#
#         st.write("Some fancy text")
#         value = st.checkbox("Check me")
#         st.write(f"Checkbox checked: {value}")

# st.page_link("frontend.py", label="Home", icon="🏠")
# st.page_link("pages/agent_page.py", label="Agents", icon="1️⃣")
def get_audio_length(audio_path):
    audio = AudioSegment.from_file(audio_path)
    return len(audio) / 1000.0  # Length in seconds

def autoplay_audio(file_path, autoplay=True):
    with open(file_path, "rb") as file:
        file_binary = file.read()
        b64 = base64.b64encode(file_binary).decode()
    if autoplay:
        md = f"""
            <audio id="audioTag" controls autoplay>
            <source src="data:audio/mp3;base64,{b64}" type="audio/mpeg" format="audio/mpeg">
            </audio>
            """
    else:
        md = f"""
            <audio id="audioTag" controls>
            <source src="data:audio/mp3;base64,{b64}" type="audio/mpeg" format="audio/mpeg">
            </audio>
            """
    # st.markdown(
    #     md,
    #     unsafe_allow_html=True,
    # )

    return md

# ------------------------------------------  Side Panel -------------------------------------------------------------------------

with st.sidebar:

    st.markdown("<h1 style='text-align: center;'>Please give your inputs here: \U0001F447</h1>", unsafe_allow_html=True)
    st.write("")
    st.markdown("<h3>Please enter the mode of input</h3>",  unsafe_allow_html=True)
    communication_option = st.radio( "Enter the communication mode", ['Text'])
    st.write("")
    st.markdown("<h3>Please enter the type of input</h3>", unsafe_allow_html=True)
    search_option = st.radio("Enter the search option", ['Pdf', 'Website'])

    if search_option == "Website":
        url_input = st.text_input("Enter the URL")
        if st.button("Submit"):
            requests.post("http://localhost:8000/website/", params={"link" : url_input })
            st.markdown("Website scrapped successfully!!!")
            # pass

    elif search_option == "Pdf":
        st.markdown( "<h3>Please upload a file which can be pdf or zip</h3>", unsafe_allow_html=True)
        file = st.file_uploader( "Please upload a file which can be pdf or zip", label_visibility="collapsed", type=["pdf"])
        if st.button("Submit"):
            if file is not None:
                requests.post("http://localhost:8000/pdf/", files={"file" : file})
                st.success("File submitted")
        else:
            pass
            # st.warning("file not submitted")


#--------------------------------------------------Main Page ----------------------------------------------------------------

st.markdown("# TE PROMPT")
st.markdown("## Voice Assistant")
st.write("")
st.write("")

if 'history' not in st.session_state:
    st.session_state.history = []

if communication_option == "Text":
    st.markdown("<h6>Type your query. </h6>", unsafe_allow_html=True)
    user_input = st.text_input("Type the query ", label_visibility="collapsed", key="user_input")
    if st.button("Send"):
        print(user_input)
        params = {'query': user_input}
        response = requests.post("http://localhost:8000/llm/", params=params)
        result = response.json()
        print("answer is : ", result)
        # st.markdown(result)
        st.session_state.history.append(f"You: {user_input}")
        st.session_state.history.append(f"Bot: {result}")
        # print(len(chat_history))
        # print(chat_history)
    t = 0
    for i in st.session_state.history:
        if t % 2 == 0:
            # st.markdown(f"<span style='color:red'>{i}</span>", unsafe_allow_html=True)
            st.markdown(f'<div class="user-message">{i}</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="bot-message">{i}</div>', unsafe_allow_html=True)
        t += 1

elif communication_option == "Voice":
    if st.button("Start Voice Chat"):
        # recording will be done here
        text_container = st.empty()

        audio_path = voicebot.record()

        with open(audio_path, "rb") as file:
            files = {"file": (audio_path, file)}
            params = {"filename": audio_path}
            response = requests.post("http://127.0.0.1:8000/transcriber/", files=files, params=params)
            transcribed_text = (response.json())[0]
            detected_lang = (response.json())[1]
            print("INFO: After recording transcribed text is : ", transcribed_text)

        answer = requests.post("http://127.0.0.1:8000/llm/", params={"query" : transcribed_text})
        text = answer.json()
        output_audio = requests.post("http://127.0.0.1:8000/voice_response/", params={"transcribed_text": answer.json() + string,'language': detected_lang })

        st.session_state.history.append(f"You: {transcribed_text}")
        st.session_state.history.append(f"Bot: {answer.json()}")

        print("INFO:  Type of output audio received : ", type(output_audio.content))
        print("type of output received is : ", type(output_audio.content))
        audio = AudioSegment.from_file(BytesIO(output_audio.content), format="mp3")
        result = "final_audio.mp3"
        audio.export(result, format="mp3")
        play = st.empty()
        md = autoplay_audio(result)
        play.markdown(md, unsafe_allow_html=True, )

        t = 0
        for i in st.session_state.history:
            if t%2 ==0:
                # st.markdown(f"<span style='color:red'>{i}</span>", unsafe_allow_html=True)
                st.markdown(f'<div class="user-message">{i}</div>', unsafe_allow_html = True)
            else:
                st.markdown(f'<div class="bot-message">{i}</div>', unsafe_allow_html = True)
            t +=1

        audio_len = get_audio_length(result)
        time.sleep(audio_len+1)
        print(audio_len)
        play.empty()
        # os.remove(result)

