# import server

from modules import *
# from server import retriever

# conversation = None
# semantic_cache = MongoDBAtlasSemanticCache(
#     embedding=GooglePalmEmbeddings(),
#     connection_string='mongodb+srv://Cluster74590:f19982000@cluster74590.iahd7nm.mongodb.net/?retryWrites=true&w=majority&appName=Cluster74590',
#     collection_name="voice",
#     database_name="mongo",
#     index_name="vector_index",
#     score_threshold=0.99,
#
# )
# semantic_cache.clear()
from langchain.schema.runnable import RunnablePassthrough

class VoiceBot():

    def __init__(self):
        # Initialize logger
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.DEBUG)
        # Create a file handler and set the formatter
        log_file_path = os.path.join(os.getcwd(), "voice_bot.log")
        file_handler = logging.FileHandler(log_file_path)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)

        # Add the file handler to the logger
        self.logger.addHandler(file_handler)
    #----------------------------------------------------------
    def record(self, name="input_recording.wav",path=os.getcwd()):
        try:
            recognizer = sr.Recognizer()
            print("listening")
            with sr.Microphone() as source:
                recognizer.adjust_for_ambient_noise(source)
                audio = recognizer.listen(source, timeout=3)

            # Save the audio to a temporary file
            audio_file_path = os.path.join(path, name)
            with open(audio_file_path, "wb") as f:
                f.write(audio.get_wav_data())
            return audio_file_path

        except Exception as e:
            self.logger.error(f"Error during recording: {str(e)}")
            return None
    # ----------------------------------------------------------

    def asr_model(self, model_size='base'):
        try:
            model = whisper.load_model(model_size)
            return model
        except Exception as e:
            self.logger.error(f"Error loading ASR model: {str(e)}")
            return None

    # ----------------------------------------------------------
    def speech_to_text(self, model, input_audio="input_recording.wav"):
        # Language detection
        audio = whisper.load_audio(input_audio)
        audio = whisper.pad_or_trim(audio)
        mel = whisper.log_mel_spectrogram(audio).to(model.device)
        _, probs = model.detect_language(mel)
        detected_language = max(probs, key=probs.get)
        # detected_language = 'en'
        start_time = time.time()
        text = model.transcribe(input_audio, fp16=False)
        print(text)
        print(
            '\033[94m' + f'INFO:      Time taken for transcribing is {round(time.time() - start_time, 2)}s' + '\033[0m')
        print(f"Detected Language: '{detected_language}' and Transcribed Text: '{text['text']}'")
        if detected_language == 'en':
            return text['text'], detected_language
        else:
            translator = Translator()
            translated_text = translator.translate(text['text'], dest='en').text
            return translated_text, detected_language
    # ----------------------------------------------------------
    def text_to_speech(self, text, path=os.getcwd(),name='output_speech.wav',language='en'):
        try:
            myobj = gTTS(text=text, lang=language, slow=False, tld="co.uk")
            audio_file_path = os.path.join(path, name)
            myobj.save(name)
            return name
        except Exception as e:
            self.logger.error(f"Error during text-to-speech conversion: {str(e)}")
            return None
# -----------------------------------------------------------------------------------------------------------------------------------

class RAG():
    def __init__(self):
        # Configure logging
        logging.basicConfig(filename='rag_log.txt', level=logging.ERROR)

    # ----------------------------------------------------------
    def rag_splitter(self, doc, chunk_size=200, overlap=40):
        # doc should be in format of " Document(page_content='LayoutParser : A Uni\x0ced Toolkit for .....)
        # This doc is the output of loading a document using loaders from langchain and load_and_split()
        try:
            splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=overlap)
            chunks = splitter.split_documents(doc)
            return chunks
        except Exception as e:
            logging.error(f"Error in rag_splitter: {e}")
            return None

    # ----------------------------------------------------------
    def rag_embeddings(self, embedding_name='palm'):
        try:
            if embedding_name == 'palm':
                embeddings = GooglePalmEmbeddings()
            else:
                embeddings_model_name = "sentence-transformers/all-MiniLM-L6-v2"
                embeddings = HuggingFaceEmbeddings(model_name=embeddings_model_name)
            return embeddings
        except Exception as e:
            logging.error(f"Error in rag_embeddings: {e}")
            return None

    # ----------------------------------------------------------
    def rag_vectorstore(self, chunks, rag_embeddings, vector_name='chroma'):
        try:
            if vector_name == 'chroma':
                retriever = (Chroma.from_documents(chunks, rag_embeddings)).as_retriever()
            else:
                retriever = (FAISS.from_documents(chunks, rag_embeddings)).as_retriever()
            return retriever
        except Exception as e:
            logging.error(f"Error in rag_vectorstore: {e}")
            return None

    def pipeline(self, doc):
        global conversation
        conversation = None
        chunks = self.rag_splitter(doc)
        embeddings = self.rag_embeddings()
        retriever = self.rag_vectorstore(chunks, embeddings)
        return retriever
# --------------------------------------------------------------------------------------------------------------------------
class Advanced_RAG():
    def __init__(self):
        # Configure logging
        logging.basicConfig(filename='rag_log.txt', level=logging.ERROR)

    def rag_embedding(self, embedding_name='palm'):
        try:
            if embedding_name == 'palm':
                embeddings = GooglePalmEmbeddings()
            else:
                embeddings_model_name = "sentence-transformers/all-MiniLM-L6-v2"
                embeddings = HuggingFaceEmbeddings(model_name=embeddings_model_name)
            return embeddings
        except Exception as e:
            logging.error(f"Error in rag_embeddings: {e}")
            return None

    def vectorstore(self, rag_embedding, name="chroma"):
        if name == 'chroma':
            vector = Chroma(embedding_function=rag_embedding)
        else:
            vector = FAISS(embedding_function=rag_embedding)

        return vector

    def rag_retriever(self, doc, vectorstore, parent_splitter_size = 2000 , child_splitter_size = 200, overlap = 20):
        try:
            parent_splitter = RecursiveCharacterTextSplitter(chunk_size=parent_splitter_size)
            child_splitter = RecursiveCharacterTextSplitter(chunk_size= child_splitter_size)
            store = InMemoryStore()
            retriever = ParentDocumentRetriever(
                vectorstore=vectorstore,
                docstore=store,
                child_splitter=child_splitter,
                parent_splitter=parent_splitter,
            )
            # print(doc)
            # retriever._collection.delete(ids=["first"])

            retriever.add_documents(doc,ids=None)
            return retriever
        except Exception as e:
            print((f"INFO: Unable to build embeddings, error : {e}!"))
            logging.error(f"Error while building embeddings {e}")

    def pipeline(self, doc):
        global  conversation
        conversation = None
        # retriever=None
        rag_embedding = self.rag_embedding('palm')
        vectorstore = self.vectorstore(rag_embedding)
        retriever =  self.rag_retriever(doc, vectorstore )
        return retriever



def conv_llm_rag(query, retriever, llm, memory):
    # llm_prompt_template = """You are an assistant for question-answering tasks.
    # Use the following context to answer the question.
    # If you don't know the answer, just say that you don't know.
    # Use five sentences maximum and keep the answer concise.\n
    # Question: {question} \nContext: {context} \nAnswer:"""
    #
    # llm_prompt = PromptTemplate.from_template(llm_prompt_template)
    # print(llm_prompt)
    # rag_chain = (
    #         {"context": retriever, "question": RunnablePassthrough()}
    #         | llm_prompt
    #         | llm
    #         | StrOutputParser()
    # )
    # ans = rag_chain.invoke(query)
    # print(ans)
    # return ans
    # question_generator_chain = LLMChain(llm=llm, prompt=prompt)
    # cached_entry = semantic_cache.similarity_search_with_relevance_scores(query, 5)
    # print(cached_entry)
    # if (cached_entry and cached_entry[0][1] <= 0.03):
    #     answer = cached_entry[0][0].to_json()['kwargs']['metadata']['response']
    #     return answer
        # print(answer)
    # ConversationalRetrievalQA should be declared only once, not everytime LLM fastapi endpoint is called, So it is declared globally and only once
    # global conversation
    # template = """You are chatbot.YOU PROVIDE INFORMATION FROM DOCUMENT PROVIDED ONLY.\n
    # You also have chat history.Gather informations from the provided DOCUMENT and provide the answer to the points only.\n
    #             If you are asked to answer in breif or detail, then try to answer in brief and detail respectively.\n
    #              Never makeup answer on your own.GIVE ANSWER ONLY FROM THE CONTEXT AND PROVIDED DOCUMENT. IF QUESTION IS NOT ASKED FROM THE PROVIDED DOCUMENT, SAY "Sorry, I dont know the answer". DO NOT MAKE ANSWER ON YOUR OWN.
    #              I REPEAT IF QUESTION IS NOT FROM PROVIDED DOCUMENT, DO NOT ANSWER THAT QUESTION. JUST SAY "SORRY" EVEN IF ANSWER IS QUIET KNOWN.
    #         ----
    #         {context}
    #         ----
    #         """
    #
    # general_user_template = "Question:```{question}```"
    # messages = [
    #     SystemMessagePromptTemplate.from_template(template),
    #     HumanMessagePromptTemplate.from_template(general_user_template)
    # ]
    #
    # qa_prompt = ChatPromptTemplate.from_messages(messages)
    # # checking if conversation is defined already. It will be defined only once
    # # if len(memory.load_memory_variables({})['chat_history']) <= 1:
    # conversation = ConversationalRetrievalChain.from_llm(combine_docs_chain_kwargs={"prompt": qa_prompt},
    #                                                          llm=llm,
    #
    #                                                          retriever=retriever, memory=memory, verbose=True)
    qa_with_sources_chain = RetrievalQA.from_chain_type(
        llm=llm,
        retriever=retriever,
        # callbacks=[handler],
        return_source_documents=True
    )
    answer = qa_with_sources_chain({"query":query})
    print((answer['source_documents']))
    return answer['result']
    # answer = conversation({"question": query})
    # cached_res = semantic_cache._insert_texts(
    #     [query],
    #     [{"response": answer['answer']}],
    #     # This ensures that if the query doesn't exist, it will be inserted
    # )
    # print("answer : ", answer)
    #
    # return answer['answer']



# ----------------------------------------------------------

def conv_llm(query, llm, memory):


        # global conversation
        # ans = llm.generate_content(query).text
        # return llm.send_message(query).text

        # cached_entry = semantic_cache.similarity_search_with_relevance_scores(query,5)
        # if cached_entry:
        #     print("----------------", cached_entry[0][1])
        # if(cached_entry and cached_entry[0][1]<=0.03):
        #     print("----------------", cached_entry[0][1])
        #     answer = (cached_entry[0][0].to_json()['kwargs']['metadata']['response'])
        #     return answer

        # checking if conversation is defined already. It will be defined only once
        # if len(memory.load_memory_variables({})['history']) <=1 :
        conversation = ConversationChain(llm=llm, memory=memory, verbose=True)
        answer =conversation.predict(input = query)
        # print(type(answer))
        # llm = ChatGoogleGenerativeAI(model="gemini-pro", google_api_key = "AIzaSyBcvQ_KcY2cr6-bBKEgdP6OE3j9t3RuBw4")
        # tweet_prompt = PromptTemplate.from_template("You are a content creator. Write me a tweet about {topic}.")
        # tweet_chain = LLMChain(llm=llm, prompt=tweet_prompt, verbose=True)
        # answer = tweet_chain.predict(input = query)
        # cached_res = semantic_cache._insert_texts(
        #     [query],
        #     [{"response": answer}],
        #     # This ensures that if the query doesn't exist, it will be inserted
        # )
        print("answer : ", answer)
        return answer
