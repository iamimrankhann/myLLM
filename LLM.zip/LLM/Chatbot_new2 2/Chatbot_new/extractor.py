from modules import *

class Website_Scrapper:

    def __init__(self):
        self.visited_urls = []
        self.website_content = []

    def data_extraction(self, url):
        try:
            self.get_all_links(url)
            self.webscrap_from_links()
            doc = self.website_content
        except Exception as e:
            logging.error(f"Error occurred loading the website. Details: {e}")
            doc = None
        return doc

    def get_links_from_a_url(self, url):
        try:
            response = requests.get(url)
            response.raise_for_status()  # Raise HTTPError for bad responses
            soup = BeautifulSoup(response.content, 'html.parser')
            url_list = [urljoin(url, link.get('href')) for link in soup.find_all('a') if link.get('href')]
            return url_list
        except requests.RequestException as e:
            logging.error(f"Error occurred while requesting {url}: {e}")
            return []

    def get_all_links(self, url):
        if len(self.visited_urls) >= 1:
            return

        try:
            list_of_urls = self.get_links_from_a_url(url)
        except Exception as e:
            logging.error(f"Error occurred while getting links from {url}: {e}")
            return

        for each_link in list_of_urls:
            if each_link not in self.visited_urls:
                ext = os.path.splitext(each_link)[1].lower()
                extensions = ['.jpg', '.jpeg', '.png', '.gif', '.mp4', '.avi', '.txt', '.pdf']
                word_anomaly = "mail"
                if ext not in extensions and word_anomaly not in each_link:
                    self.visited_urls.append(each_link)
                    self.get_all_links(each_link)
    def webscrap_from_links(self):
        for link in self.visited_urls:
            ext = os.path.splitext(link)[1].lower()
            extensions = ['.jpg', '.jpeg', '.png', '.gif', '.mp4', '.avi', '.txt', '.pdf']
            if ext not in extensions:
                try:
                    response = requests.get(link)
                    response.raise_for_status()
                    content = response.text
                    soup = BeautifulSoup(content, "html.parser")
                    page_text = soup.body.get_text() if soup.body else ''
                    # Replace multiple \n with a single space
                    string = re.sub(r'\n+', ' ', page_text)
                    self.website_content.append(string)
                except requests.RequestException as e:
                    logging.error(f"Error occurred while scraping {link}: {e}")