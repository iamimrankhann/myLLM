from modules import *
from Voicebot import *
from Agents import *
from extractor import Website_Scrapper
# import frontend
app = FastAPI(max_request_size=1000*1024*1024)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"], )
# Custom classes
RAG = RAG()
VoiceBot = VoiceBot()
Advanced_RAG = Advanced_RAG()
# ASR model and LLM is needed to be declared only once. So it is declared globally
# model = VoiceBot.asr_model()
llm = GooglePalm(temperature=0.2)

conv_memory = ConversationBufferMemory(memory_key="history", return_messages=True)
rag_memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
conv_memory.clear()
rag_memory.clear()
# The data has to be stored in the database only once. So it is declared globally
retriever = None

#-----------------------------------------------------------------------------------------------------------------------

@app.post('/pdf/')
async def data_extraction(file: UploadFile = File(...)):
    start_time = time.time()
    global retriever
    retriever = None
    print("INFO:    PDF post request hit successfully")
    file_contents = await file.read()
    # Create a temporary file to write the contents
    with tempfile.NamedTemporaryFile(delete=False) as temp_file:
        temp_file.write(file_contents)
        temp_file.seek(0)
    doc = PyPDFLoader(temp_file.name).load_and_split()
    print("INFO:    PDF was loaded successfully!!!")
    rag_memory.clear()
    retriever = Advanced_RAG.pipeline(doc)
    print("INFO:    Retriever built successfully..........")
    print('\033[94m' + f'INFO:      Time taken for data extraction from PDF is {round(time.time() - start_time, 2)}s' + '\033[0m')

#-----------------------------------------------------------------------------------------------------------------------

@app.post('/website/')
async def data_extraction(link: str):
    start_time = time.time()
    print("INFO:   website post request hit successfully ")
    print("INFO:   Website is", link)
    global retriever
    retriever=None
    doc = Website_Scrapper().data_extraction(link)
    print("INFO : Size of scrapped text : ", len(doc))
    print("Scrapped text : ", doc)
    print("INFO: Website data is extracted successfully!")
    doc = [Document(page_content=doc[0], metadata={"source": "local"})]
    print("INFO : Size of document : ", len(doc))
    rag_memory.clear()
    retriever = Advanced_RAG.pipeline(doc)
    print('\033[94m' + f'INFO:      Time taken for data extraction from website is {round(time.time() - start_time, 2)}s' + '\033[0m')

#-----------------------------------------------------------------------------------------------------------------------

@app.post('/transcriber/')
async def voice_process(file:UploadFile = File(...)):
    start_time = time.time()
    print('INFO:   Post request recieved!!!')
    print(f"INFO:   {type(file.file)}")
    """ The uploaded file is received as tempfile.SpooledTemporaryFile
    so it needs to be converted to WAV or MP3"""
    received_file = "Received_audio.wav"
    audio = AudioSegment.from_file(file.file, format="wav")
    audio.export(received_file, format="wav")
    print(f"INFO:   Conversion completed. File saved as {received_file} and type {received_file.split('.')[1]}")
    #------------------------------------------------------------------------
    transcribed_text, language = VoiceBot.speech_to_text(model,received_file)
    print('\033[94m' + f'INFO:      Time taken for transcribing is {round(time.time() - start_time, 2)}s' + '\033[0m')
    return transcribed_text, language

#-----------------------------------------------------------------------------------------------------------------------

@app.post('/llm/')
async def llm_process(query: str):
    start_time = time.time()
    print("INFO:    LLM post request hit successfully!!!!!!")
    global retriever
    if retriever:
        answer = conv_llm_rag(query = query,retriever= retriever,llm= llm,memory= rag_memory)
    else:
        print("INFO:    Retriever not found, so predicting from LLM....")
        # answer = conv_llm(query, llm, conv_memory)
        answer = conv_llm(query, llm, conv_memory)
        # answer = llm(query)
        # llm_cache.update(prompt=query,llm_string=query, return_val=answer)
    print('\033[94m' + f'INFO:      Time taken for LLM is {round(time.time() - start_time, 2)}s' + '\033[0m')
    return answer
#-----------------------------------------------------------------------------------------------------------------------

@app.post('/voice_response/')
async def voice_response(transcribed_text: str, language:str):
    start_time = time.time()
    print("INFO:    Voice_response post request hit successfully!!!")
    audio_output = VoiceBot.text_to_speech(transcribed_text, language=language)
    print("INFO:    Voice response generated successfully.....")
    print((audio_output))
    print('\033[94m' + f'INFO:      Time taken for voice response= is {round(time.time() - start_time, 2)}s' + '\033[0m')
    return StreamingResponse(open(audio_output,"rb"),media_type='audio/mp3',headers={"Content-Disposition": "attachment; filename=output.mp3"})

#-----------------------------------------------------------------------------------------------------------------------

@app.post('/teams_trial')
async def trial(request:Request):
    # print("-----", request)
    request_body = await request.body()
    # req = {
    #     "headers": {
    #         "Authorization": "8aV0pnsrNiDfWN3KzdtrbJV7kys8o9Dg5DfxVqFansI="   # Replace with the provided HMAC value
    #     },
    #     "payload": "Hello, World!"
    # }
    # if verify_request(req, shared_secret):
    #     print("Request is authentic")
    # else:
    #     print("Request is not authentic")
    # Convert the request body from bytes to string
    request_body_str = request_body.decode('utf-8')
    # print("Request body string :", request_body_str)
    # Parse the request body as JSON
    request_data = json.loads(request_body_str)
    #For Extracting the trigger word to remove it from query string
    print("Request data :", request_data.get('attachments')[0].get('content'))
    html_string = request_data.get('attachments')[0].get('content')
    soup = BeautifulSoup(html_string, 'html.parser')
    trigger_word = soup.span.get_text()
    # print(trigger_word)



    activity_type = request_data.get('activity', {}).get('type')
    conversation_id = request_data.get('conversation', {}).get('id')
    from_user = request_data.get('from', {}).get('name')
    message_text = request_data.get('text')

    message_text = html.unescape(message_text)
    # Use a regular expression to extract only the text content
    message_text = re.sub(r'<[^>]+>', '', message_text)
    message_text = message_text[len(trigger_word)+1:]
    print("from user : ", from_user)
    print("type of message text :", type(message_text))
    print("message text : ", message_text)
    answer = conv_llm_rag(llm=llm, query=message_text, memory=rag_memory, retriever=retriever)
    payload = {
        "type": "message",
        "text": answer
    }
    return payload
#-----------------------------------------------------------------------------------------------------------------------

#-----------------------------------------------------------------------------------------------------------------------


@app.post('/agent')
async def agent(query:str):
    response = basic_agent(query)
    return response


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)