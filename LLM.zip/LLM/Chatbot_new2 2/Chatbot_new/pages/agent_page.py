import streamlit

from modules import *
#
# with st.expander("Weather"):
#     location = st.text_input("Location")
#
#     if(location):
#         response = requests.post("http://127.0.0.1:8000/weather", params={"location":location})
#         response = response.json()
#         print(response)
#         st.write("Current Condition : ", response[0]['text'])
#         st.write("Current temperature(in C) : ", response[1])
#
#
# with st.expander("Location"):
#     if st.button("Current_Location"):
#             # Get the current location
#         response = requests.post("http://127.0.0.1:8000/location").json()
#         st.write("City : ", response['city'])
#         st.write("State : ", response['state'])

st.markdown("Type your Query related to recent events...")
api_key = st.text_input("Please enter you Tavily API key  ")
if st.button("Send", key=1):
    os.environ["TAVILY_API_KEY"] = api_key
user_input = st.text_input("Enter you query : ")
if st.button("Send"):
    response = requests.post("http://localhost:8000/agent/", params={"query" : user_input}).json()
    print(response)
    st.markdown(f"Query : {response['input']}")
    st.markdown(f"Answer :  {response['output']}")
